# 最全面的 C++ 笔记

视频讲解：

1. https://www.bilibili.com/video/BV1et411b73Z?p=1

备注：安装Jupyter Notebook的目录插件，可以快速通过目录，跳转到相应的章节，如下图所示。

![image](https://user-images.githubusercontent.com/60348867/161884474-639f8818-5427-428d-a3a2-337c6ce776d3.png)

备注：笔记是用Jupyter Notebook打开的，可以看下面链接，进入“00_Python编辑器”中，里面有我写的笔记，或者百度、谷歌查一查“如何运行Jupyter notebook文件”即可。

1. https://github.com/AccumulateMore/Python

补充：我的Github主页，还有其他优秀视频的笔记，希望能帮助到你~~♥

1. https://github.com/AccumulateMore

"♥我的笔记，希望对你有帮助♥"

♥小声哔哔：你的star，是我更新的动力~♥
